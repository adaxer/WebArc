﻿using Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ADMovie.ViewModels
{
    public class ServiceLocator : IServiceLocator
    {
        static IServiceLocator s_Instance;
        public static IServiceLocator Current { get { return s_Instance; } }

        public static void SetLocator(IServiceLocator implementation)
        {
            s_Instance=implementation;
        }

        public object GetInstance(Type type, string key)
        {
            return s_Instance.GetInstance(type, key);
        }

        public T GetInstance<T>(string key)
        {
            return s_Instance.GetInstance<T>(key);
        }

        public object GetInstance(Type type)
        {
            return GetInstance(type, null);
        }

        public T GetInstance<T>()
        {
            return GetInstance<T>(null);
        }
    }
}
