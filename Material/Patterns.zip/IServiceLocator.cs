﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interfaces
{
    public interface IServiceLocator
    {
        object GetInstance(Type type, string key);
        T GetInstance<T>(string key);
        object GetInstance(Type type);
        T GetInstance<T>();
    }
}
