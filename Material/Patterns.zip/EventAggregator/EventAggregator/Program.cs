﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventAggregator
{
    class Program
    {
        static void Main(string[] args)
        {
            IEventAggregator ea = new EventAggregator();
            var src = new EventSource(ea);
            var tgt = new EventTarget(ea);
            src.FireEvent();
        }
    }

    public class EventAggregator : IEventAggregator
    {
        Dictionary<Type, Dictionary<string, object>> m_Subscribers = new Dictionary<Type, Dictionary<string, object>>();

        public void Subscribe<T>(IHandle<T> receiver, string cookie)
        {
            if (!m_Subscribers.ContainsKey(typeof(T)))
                m_Subscribers[typeof(T)] = new Dictionary<string, object> { { cookie, receiver } };
        }

        public void Publish<T>(T payload, string cookie = null)
        {
            if (m_Subscribers.ContainsKey(typeof(T)))
                foreach (string key in m_Subscribers[typeof(T)].Keys)
                    if (cookie.Equals(key))
                        ((IHandle<T>)m_Subscribers[typeof(T)][key]).Handle(payload);
        }
    }

    public class EventTarget : IHandle<string>
    {
        string cookie = Guid.NewGuid().ToString();
        public void FireEvent()
        {
            Events.Publish<string>("Event um: " + DateTime.Now.ToLongTimeString(), cookie);
        }

        public EventTarget(IEventAggregator eventAggregator)
        {
            Events = eventAggregator;
            Events.Subscribe<string>(this, "stringEvent");
        }

        internal IEventAggregator Events { get; set; }

        public void Handle(string t)
        {
            Console.WriteLine("Event erhalten: " + t);
        }
    }

    public class EventSource
    {
        public void FireEvent()
        {
            Events.Publish<string>("Event um: " + DateTime.Now.ToLongTimeString(), "stringEvent");
        }

        public EventSource(IEventAggregator eventAggregator)
        {
            Events = eventAggregator;
        }

        internal IEventAggregator Events { get; set; }
    }


    public interface IEventAggregator
    {
        void Subscribe<T>(IHandle<T> receiver, string cookie);
        void Publish<T>(T payload, string cookie = null);
    }

    public interface IHandle<T>
    {
        void Handle(T t);
    }
}

