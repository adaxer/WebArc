﻿using System;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello Woerld!");
            Console.Beep(1300,300);
            //Console.ReadLine();
        }
    }
}
