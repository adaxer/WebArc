class App{
    constructor(appName: string) {
        document.getElementById("body").innerHTML = appName;
    }
}
