import { Component } from '@angular/core';
import { ProductListComponent } from './products/product-list.component';
import { ProductService } from './products/product.service';
import 'rxjs/Rx';

@Component({
    selector: 'pm-app',
    template: `
        <div>
        <h1>{{pageTitle}}</h1>
        <pm-products></pm-products>
        </div> `,
    entryComponents: [ProductListComponent],
    providers: [ProductService]

})
export class AppComponent { 
    pageTitle: string = 'Acme Product Offers';
}
